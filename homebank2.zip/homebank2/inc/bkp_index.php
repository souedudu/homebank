<table width="534" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="534"><img src="img/dot_branco.jpg" width="1" height="10"></td>
        </tr>
      </table>
        <table width="527" border="0" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF">
          <tr>
            <td width="32" height="16"><img src="img/dot_branco.jpg" width="30" height="1"></td>
            <td colspan="5" valign="top"><strong>Movimenta&ccedil;&atilde;o nos &uacute;ltimos 05 (cinco) dias </strong></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td width="83" bgcolor="f7f4f4">
              <div align="left">Data </div></td>
            <td width="98" bgcolor="f7f4f4">
              <div align="center">Ag. de Origem</div></td>
            <td width="91" bgcolor="f7f4f4">
              <div align="center">Hist&oacute;rico</div></td>
            <td width="130" bgcolor="f7f4f4">
              <div align="center">Documento</div></td>
            <td width="86" bgcolor="f7f4f4">
              <div align="center">Valor</div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td bgcolor="f7f4f4">02/09/2005</td>
            <td bgcolor="f7f4f4">
              <div align="center">0000</div></td>
            <td bgcolor="f7f4f4">
              <div align="center">saldo anterior</div></td>
            <td bgcolor="f7f4f4">
              <div align="center">0000</div></td>
            <td bgcolor="f7f4f4">
              <div align="center"><font color="#003366">633,06C</font></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>03/09/2005</td>
            <td><div align="center">0000</div></td>
            <td><div align="center">saldo</div></td>
            <td><div align="center">0000</div></td>
            <td><div align="center"><font color="#003366">700,00C</font></div></td>
          </tr>
          <tr>
            <td height="13">&nbsp;</td>
            <td>04/09/2005</td>
            <td><div align="center">0000</div></td>
            <td><div align="center">saldo</div></td>
            <td><div align="center">0000</div></td>
            <td>
              <div align="center"><font color="#003366">188,89C</font></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>05/09/2005</td>
            <td><div align="center">0000</div></td>
            <td><div align="center">saldo</div></td>
            <td><div align="center">0000</div></td>
            <td><div align="center"><font color="#003366">600,97C</font></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>06/09/2005</td>
            <td><div align="center">0000</div></td>
            <td><div align="center">saldo</div></td>
            <td><div align="center">0000</div></td>
            <td><div align="center"><font color="#003366">207,57C</font></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>07/09/2005</td>
            <td><div align="center">0000</div></td>
            <td><div align="center">saldo</div></td>
            <td><div align="center">0000</div></td>
            <td><div align="center"><font color="#003366">102,00C</font></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>08/09/2005</td>
            <td><div align="center">0000</div></td>
            <td><div align="center">saldo</div></td>
            <td><div align="center">0000</div></td>
            <td><div align="center"><font color="#003366">404,91C</font></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>09/09/2005</td>
            <td><div align="center">0000</div></td>
            <td><div align="center">saldo</div></td>
            <td><div align="center">0000</div></td>
            <td><div align="center"><font color="#003366">807,40C</font></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>10/09/2005</td>
            <td><div align="center">0000</div></td>
            <td><div align="center">saldo</div></td>
            <td><div align="center">0000</div></td>
            <td><div align="center"><font color="#003366">100,00C</font></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>11/09/2005</td>
            <td><div align="center">0000</div></td>
            <td><div align="center">saldo</div></td>
            <td><div align="center">0000</div></td>
            <td><div align="center"><font color="#003366">200,00C</font></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td bgcolor="f7f4f4">12/09/2005</td>
            <td bgcolor="f7f4f4">
              <div align="center">0000</div></td>
            <td bgcolor="f7f4f4">
              <div align="center">saldo</div></td>
            <td bgcolor="f7f4f4">
              <div align="center">0000</div></td>
            <td bgcolor="f7f4f4">
              <div align="center"><font color="#003366"><strong>200,00C</strong></font></div></td>
          </tr>
        </table>
        <table width="526" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><img src="img/dot_branco.jpg" width="1" height="20"></td>
          </tr>
        </table>
        <table width="525" border="0" cellspacing="0" cellpadding="0">
          <tr bgcolor="dedfd0">
            <td colspan="4"><img src="img/noticias.gif" width="116" height="21"></td>
          </tr>
          <tr>
            <td width="20"><img src="img/dot_branco.jpg" width="20" height="8"></td>
            <td width="242">&nbsp;</td>
            <td width="12" rowspan="4" valign="top" background="img/tracado.jpg"><img src="img/tracadoimg.jpg" width="11" height="6"></td>
            <td width="251">&nbsp;</td>
          </tr>
          <tr>
            <td height="41">&nbsp;</td>
            <td valign="top">
              <div align="left">Aqui vai ser uma chamada para not&iacute;cia de aproximadamente quatro linhas.Clicando na chamada, abrir&aacute; a not&iacute;cia inteira.</div></td>
            <td valign="top">Aqui vai ser uma chamada para not&iacute;cia de aproximadamente quatro linhas.Clicando na chamada, abrir&aacute; a not&iacute;cia inteira.</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><div align="right"><img src="img/saibamais.jpg" width="67" height="12"></div></td>
            <td><div align="right"><img src="img/saibamais.jpg" width="67" height="12"></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
      </table>