<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.: Home Bank - Solicita��o de Servi�os Banc�rios :.</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="../admin/site.css" rel="stylesheet" type="text/css">

</head>

<body>
<table width="442" height="255" border="1" align="center" cellpadding="2" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td height="23" colspan="3" class= "td2" align="center"><b>Manuten&ccedil;&atilde;o do Banco</b><br />
    <b>Carga de Dados:</b></td>
  </tr>
  <tr>
    <td width="178" height="23"><div align="center"><strong>Tabela</strong></div></td>
    <td width="176"><div align="center"><strong>Arquivo</strong></div>
        <div align="center"></div></td>
    <td width="68"><div align="center">&nbsp;</div>      <div align="center"></div></td>
  </tr>
  <tr>
    <td height="23" bgcolor="#f4f4f4"><div align="center">Cliente</div></td>
    <td class="td3"><div align="center">Cadastro.txt</div>
        <div align="center"></div></td>
    <td class="td2"><div align="center"><a href="etl_Cadastro.php" class="a">Carregar</a></div>      <div align="center"></div></td>
  </tr>
  <tr>
    <td height="23" bgcolor="#f4f4f4"><div align="center">Cliente</div></td>
    <td class="td3"><div align="center">Endereco.txt</div>
        <div align="center"></div></td>
    <td class="td2"><div align="center"><a href="etl_Endereco.php" class="a">Carregar</div>
        <div align="center"></div></td>
  </tr>
  <tr>
    <td height="23" bgcolor="#f4f4f4"><div align="center">Cliente</div></td>
    <td class="td3"><div align="center">Trabalha.txt</div>
        <div align="center"></div></td>
    <td class="td2"><div align="center"><a href="etl_Trabalha.php" class="a">Carregar</div>
        <div align="center"></div></td>
  </tr>
  <tr>
    <td height="23" bgcolor="#f4f4f4"><div align="center">ContaCapital</div></td>
    <td class="td3"><div align="center">ContaCapital.txt</div>
        <div align="center"></div></td>
    <td class="td2"><div align="center"><a href="etl_ContaCapital.php" class="a">Carregar</a></div>
        <div align="center"></div></td>
  </tr>
  <tr>
    <td height="23" bgcolor="#f4f4f4"><div align="center">ContaCorrente</div></td>
    <td class="td3"><div align="center">ContaCorrente.txt</div>
        <div align="center"></div></td>
    <td class="td2"><div align="center"><a href="etl_ContaCorrente.php" class="a">Carregar</a></div>
        <div align="center"></div></td>
  </tr>
  <tr>
    <td height="23" bgcolor="#f4f4f4"><div align="center">DevolucaoCH</div></td>
    <td class="td3"><div align="center">DevolucaoCH.txt</div>
        <div align="center"></div></td>
    <td class="td2"><div align="center"><a href="etl_DevolucaoCH.php" class="a">Carregar</a></div>
        <div align="center"></div></td>
  </tr>
  <tr>
    <td height="23" bgcolor="#f4f4f4"><div align="center">ContratoCredito</div></td>
    <td class="td3"><div align="center">ContratoCredito.txt</div>
        <div align="center"></div></td>
    <td class="td2"><div align="center"><a href="etl_ContratoCredito.php" class="a">Carregar</div>
        <div align="center"></div></td>
  </tr>
  <tr>
    <td height="23" bgcolor="#f4f4f4"><div align="center">PlanoPagamento</div></td>
    <td class="td3"><div align="center">PlanoPagamento.txt</div>
        <div align="center"></div></td>
    <td class="td2"><div align="center"><a href="etl_PlanoPagamento.php" class="a">Carregar</div>
        <div align="center"></div></td>
  </tr>
  <tr>
    <td height="23" bgcolor="#f4f4f4"><div align="center">SeguroPrestamista</div></td>
    <td class="td3"><div align="center">SeguroPrestamista.txt</div>
        <div align="center"></div></td>
    <td class="td2"><div align="center"><a href="etl_SeguroPrestamista.php" class="a">Carregar</a></div>
        <div align="center"></div></td>
  </tr>
  <tr>
    <td height="23" bgcolor="#f4f4f4"><div align="center">LancamentosCCapital</div></td>
    <td class="td3"><div align="center">LancamentosCCapital.txt</div>
        <div align="center"></div></td>
    <td class="td2"><div align="center"><a href="etl_LancamentosCCapital.php" class="a">Carregar</a></div>
        <div align="center"></div></td>
  </tr>
  <tr>
    <td height="23" bgcolor="#f4f4f4"><div align="center">AplicacaoCapRem</div></td>
    <td class="td3"><div align="center">AplicacaoCapRem.txt</div>
        <div align="center"></div></td>
    <td class="td2"><div align="center"><a href="etl_AplicacaoCapRem.php" class="a">Carregar</a></div>
        <div align="center"></div></td>
  </tr>
  
  <tr>
    <td height="23" bgcolor="#f4f4f4"><div align="center">ContaCapRemunerada</div></td>
    <td class="td3"><div align="center">ContaCapRemunerada.txt</div>
        <div align="center"></div></td>
    <td class="td2"><div align="center"><a href="etl_ContaCapRemunerada.php" class="a">Carregar</a></div>
        <div align="center"></div></td>
  </tr> 

  <tr>
    <td height="23" bgcolor="#f4f4f4"><div align="center">LancamentoCapRem</div></td>
    <td class="td3"><div align="center">LancamentoCapRem.txt</div>
        <div align="center"></div></td>
    <td class="td2"><div align="center"><a href="etl_LancamentoCapRem.php" class="a">Carregar</a></div>
        <div align="center"></div></td>
  </tr>
</table>
<table width="442" border="0" align="center" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td align="center"><a href="javascript:(history.back(-1))"><img src="../img/bt_voltar.gif" width="53" height="20" border="0"></a></td>
  </tr>
</table>
</body>
</html>
