<?

include("../library/config.php");
include("../library/funcoes.php");

$pg = split("/",$_SERVER['PHP_SELF']);
$nomePAG = $pg[count($pg)-1];

//if($nomePAG=="")$nomePAG="login.php";

		/* Verifica se a se��o est� aberta */
		if(empty($_SESSION['logadoadm'])){

			/* Habilita como padr�o a p�gina Login */
			$nomePAG="login.php";
			/* Valida se o usu�rio clicou no bot�o logar */
			if(!empty($_REQUEST['btLogin'])){

                /* Coleta as vari�veis do formul�ro login*/
				$VtxtContaCorrente = $_POST['txtContaCorrente'];
				$VtxtSenha = $_POST['txtSenha'];

				/* Verifica se os dados passados pelo formul�rio est�o vazios */
				if(($VtxtContaCorrente != "") && ($VtxtSenha != ""))
				{

					if(Conexao($opcao='open',conexao_host,conexao_user,conexao_pass,conexao_db))
					{

						/* Query SQL para verifica��o dos dados do cliente */
						$SelLogin[0] = "SELECT * FROM usuario ".
						               " Where dessenha = '".$VtxtSenha."'".
									   " and desusuario = '".$VtxtContaCorrente."'";

						if(VerificaRegistro($SelLogin[0])){
							$SelLogin[1] = mysql_query($SelLogin[0]);
							$ResLogin = mysql_fetch_array($SelLogin[1]);

							/* Vari�veis gerais */
							$_SESSION['codusuarioadm'] = $ResLogin['codusuario'];
							$_SESSION['codtecnicorespadm'] = $ResLogin['codtecnicoresp'];
							$_SESSION['desusuario'] = strtoupper($ResLogin['desusuario']);
							$_SESSION['flaencerraros'] = $ResLogin['flaencerraros'];							
							$_SESSION['flaconcluiros'] = $ResLogin['flaconcluiros'];
							$_SESSION['ultimo_acesso'] = $ResLogin['dtultimoacesso'];
							$_SESSION['flapercadusu'] = $ResLogin['flapercadusu'];
							$_SESSION['flapercadmenu'] = $ResLogin['flapercadmenu'];
							$_SESSION['ultimo_acesso'] = $ResLogin['dtultimoacesso'];							
							                            
							$dataultacesso = FormataData($_SESSION['ultimo_acesso'],$formato='pt');
							
							$datault = date("Y-m-d");
							
							$_SESSION['ultimo_acesso'] = $datault;
							
							
														
							
							//****Atualiza data de ultimo Acesso do Usu�rio*******//
							$sqlStringdataultacesso = "update usuario set dtultimoacesso = '".$datault."' where codusuario = ".$_SESSION['codusuarioadm'];																										
	    					$rsqrydataultacesso = mysql_query($sqlStringdataultacesso);    						
							


							$_SESSION['logadoadm'] = 'ok';

							/* Inclui p�gina inicial */
							$nomePAG="inicio.php";

							//$nomePAG="login.php";

                        	
							

						}else{
							$ValLoginErro="<b>Dados incorretos, tente novamente.</b>";
						}
						Conexao($opcao='close');
					}
					else
					{
                            $ValLoginErro="<b>Dados incorretos, tente novamente.</b>";
					}
				}
			}
		}

	
		

	?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>:. HOMEBANKING .:</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="site.css" rel="stylesheet" type="text/css">
<script src="../scripts.js" type="text/javascript"></script>
<script language="JavaScript" src="../mm_menu.js"></script>

<?
    // Monta Menu
    if(!empty($_SESSION['logadoadm']))
      include ("menupopup.php");


?>
<style type="text/css">
<!--
.style4 {
	color: #333333;
	font-weight: bold;
}
-->
</style>
</head>

<body background="../img/bg.gif" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<script language="JavaScript1.2">mmLoadMenus();</script>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="top">
    <td width="259"><a href="index.php"><img src="../img/logomarca.jpg" width="284" height="61" border="0"></a></td>
    <td width="511" valign="bottom" background="../img/bg_topo.jpg">
      <table width="475" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="80" align="right">
		     <? if(!empty($_SESSION['codusuarioadm']))
			   echo "<font color='#FFFFFF'>Usu�rio:&nbsp;";
             ?>
		  </td>
          <td><font color="#FFFFFF"><?
		  if(!empty($_SESSION['codusuarioadm'])){
		  	echo($_SESSION['codusuarioadm']);
		  }?></font><font color="#FFFFFF"> <?
		  if(!empty($_SESSION['desusuario'])){
		  	echo " - ".($_SESSION['desusuario']);
		  }?>
          </font></td>
          <td width="78">
<? 				if(!empty($_SESSION['codusuarioadm'])){
 		          echo "<img src='../img/ultimo_acesso.jpg' width='75' height='17'>";
?> 
		  </td>
          <td width="66"><font color="#FFFFFF"><? echo FormataData($_SESSION['ultimo_acesso'],$formato='pt'); ?></font></td>
        </tr>
<?
					
					}
?>
    </table></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2" valign="top" background="../img/bg_caixapostal.jpg"><img src="img/menu.jpg" name="image1" width="770" height="24" border="0" usemap="#Map" id="image1"></td>
  </tr>
  <tr>
  	<td width="197" height="34" valign="top" background="img/bg_caixapostal.jpg"><img src="img/topo01.jpg" usemap="#Map2" id="image2" width="203" height="113" border="0"></td>
    <td width="567" height="113"valign="top" background="img/topo02.jpg">
	<?
	if ($_SESSION['logadoadm'] != ""){
		
		// Abre conex�o com o bd
		$achou = Conexao($opcao='open',conexao_host,conexao_user,conexao_pass,conexao_db);
		
		$sqlStringAviso = "Select * From aviso where codpainel = 0 and flaativo = 's' order by dataviso desc";
	    $rsqryAviso = mysql_query($sqlStringAviso);
    	$rsavisoadmin = mysql_fetch_array($rsqryAviso);
?>
	  <div style="position: fixed; top:0px; margin-left:307px; left: 311px; height: 89px; width: 239px;" align="center"> 
	    <p class="style4"><? if ($rsavisoadmin['desaviso']) echo "<BR>".$rsavisoadmin['desaviso']."<BR>Postada em (".FormataData($rsavisoadmin['dataviso'],'pt').")";?></p>
      </div>
	  
<?	
	}else{
?>
	  <div style="position: fixed; top:95px; margin-left:307px; left: 311px; height: 89px; width: 239px;" align="center"> 
	    <p class="style4"><br>Fa�a o Seu LOGIN!</p>
      </div>
<?	
	}
?>	</td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="5" valign="top" bgcolor="#FFFFFF"><img src="../img/dot_branco.jpg" width="1" height="5"></td>
  </tr>
</table>


<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="top">
<?
  $nomePAGcount = strlen($nomePAG);
  $nomePAGcount = $nomePAGcount - 4;
  $nomePAGaux = substr($nomePAG, 0, $nomePAGcount);

?>
  
    <td width="267"  bgcolor="828916"><img src="img/<?=$nomePAGaux?>.jpg"></td>
    <td width="335" bgcolor="828916">&nbsp;</td>
    <td width="170" bgcolor="#828916">&nbsp;</td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td>&nbsp;
        <BR>
		<?
            switch($nomePAG)
            {
			 default: include("inc/$nomePAG");
			}
        ?>
		<br>
    </td>	
  </tr>
</table>

<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="../img/rodape.gif" width="770" height="63"></td>
  </tr>
</table>



<map name="Map">
<?
   
   
   //Cr�tica de Acesso ao Menu Cadastrar Usu�rio
   if ($_SESSION['flapercadusu'] == "s")
   {
    $cadastrausuario = "cadastrausuario.php";
   }else{
         $cadastrausuario = "#";
   }
   
   //Cr�tica de Acesso ao Menu Cadastrar Menu
   if ($_SESSION['flapercadmenu'] == "s")
   {
    $cadastramenu = "cadastramenu.php";
   }else{
         $cadastramenu = "#";
   }
   //Cr�tica de Acesso ao Menu Consultar OS
   if ($_SESSION['flapercadmenu'] == "s")
   {
    $cadastramenu = "cadastramenu.php";
   }else{
         $cadastramenu = "#";
   }
   //Cr�tica de Acesso ao Menu Concluir OS
   if ($_SESSION['flaconcluiros'] == "s")
   {
    $concluisolicitacao = "concluisolicitacao.php";
   }else{
         $concluisolicitacao = "";
   }
   
?>
<area shape="rect" coords="61,4,145,20" href="<?=$cadastrausuario?>" onMouseOut="MM_startTimeout();">

<area shape="rect" coords="175,3,256,21" href="<?=$cadastramenu?>" onMouseOut="MM_startTimeout();">
<area shape="rect" coords="280,4,331,20" href="#" onMouseOver="MM_showMenu(window.menu_1,283,21,null,'image1')" onMouseOut="MM_startTimeout();">
<area shape="rect" coords="350,5,399,21" href="#" onMouseOver="MM_showMenu(window.menu_2,350,21,null,'image1')" onMouseOut="MM_startTimeout();">

<area shape="rect" coords="415,2,476,21" href="alterarsenha.php" onMouseOut="MM_startTimeout();">
<area shape="rect" coords="498,2,518,19" href="logout.php" onMouseOut="MM_startTimeout();">

<area shape="rect" coords="498,2,515,21" href="logout.php" onMouseOut="MM_startTimeout();">

</map>
<?
//Cr�tica de Acesso ao Menu Consultar OS
   if ($_SESSION['logadoadm'] != "")
   {
   	// Abre conex�o com o bd
		$achou = Conexao($opcao='open',conexao_host,conexao_user,conexao_pass,conexao_db);
		
		$sqlString = "Select * From acessousu where codusuario = ".$_SESSION['codusuarioadm']." and codmenu = 31";
	    $rsqry = mysql_query($sqlString);
    	$rs = mysql_fetch_array($rsqry);
		
		if($rs){
			$consultasolcliente = "consultasolcliente.php";		
		}else{
				$consultasolcliente = "";
		}

?>
<map name="Map2">

<area shape="rect" coords="46,27,111,41" href="solicitacao.php?tipoacao=Incluir" onMouseOut="MM_startTimeout();">
<area shape="rect" coords="46,46,108,60" href="<?=$consultasolcliente?>" onMouseOut="MM_startTimeout();">
<area shape="rect" coords="46,63,102,77" href="<?=$concluisolicitacao?>" onMouseOut="MM_startTimeout();">
<area shape="rect" coords="46,81,85,95" href="solicitatriagem.php" onMouseOut="MM_startTimeout();">
<area shape="rect" coords="46,99,150,113" href="andamentosolicitacao.php" onMouseOut="MM_startTimeout();">

</map>
<?
	}
?>
</body>
</html>
