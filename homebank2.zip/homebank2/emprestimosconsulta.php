<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>:. homebanking .:</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilo.css" rel="stylesheet" type="text/css">
</head>

<body background="img/bg.gif" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="top"> 
    <td width="259"><a href="index.php"><img src="img/logomarca.jpg" width="284" height="61" border="0"></a></td>
    <td width="511" valign="bottom" background="img/bg_topo.jpg">
<table width="475" border="0" cellspacing="0" cellpadding="0">
        <tr valign="top"> 
          <td width="75"><img src="img/contacorrente2.gif" width="75" height="17"></td>
          <td width="48" valign="middle"><font color="#FFFFFF">11604-7</font></td>
          <td width="9" valign="top"><font color="#FFFFFF">_</font></td>
          <td width="125" valign="middle"><font color="#FFFFFF">Fl&aacute;vio 
            Soares Fraz&atilde;o</font></td>
          <td width="80" valign="middle"><img src="img/ultimo_acesso.jpg" width="75" height="17"> 
          </td>
          <td width="138" valign="middle"><font color="#FFFFFF">12/09/2005 - 08:32 
            hs</font></td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="197" valign="top" background="img/bg_caixapostal.jpg"><img src="img/miolo_topo1.jpg" width="203" height="146"></td>
    <td width="573" rowspan="2" valign="top"><img src="img/miolo_topo2.jpg" width="567" height="188"></td>
  </tr>
  <tr> 
    <td height="34" valign="top" background="img/bg_caixapostal.jpg">
<table width="203" height="34" border="0" cellpadding="0" cellspacing="5">
        <tr>
          <td width="193" height="24" valign="top"><font color="#FFFFFF">Voc&ecirc; 
            tem 02 mensagens novas na sua caixa de entrada.</font></td>
        </tr>
      </table></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="5" valign="top" bgcolor="#FFFFFF"><img src="img/dot_branco.jpg" width="1" height="5"></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="top"> 
    <td width="203"><img src="img/contacorrente.gif" width="203" height="21"></td>
    <td width="335" bgcolor="828916">&nbsp;</td>
    <td width="232"><img src="img/importante.gif" width="234" height="21"></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td width="536" valign="top"><table width="534" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="534"><img src="img/dot_branco.jpg" width="1" height="10"></td>
        </tr>
      </table>
      <table width="527" border="0" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF">
        <tr> 
          <td width="32" height="16"><img src="img/dot_branco.jpg" width="30" height="1"></td>
          <td colspan="5" valign="top"><strong>Consulta de Empr&eacute;stimos: 
            Desconto em Folha</strong></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td colspan="5" bgcolor="#C0C0C0"> <div align="left"><font color="#FFFFFF"><strong>Dados 
              do Cliente</strong></font></div>
            <div align="center"></div></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td width="83" bgcolor="f7f4f4">Nome:</td>
          <td colspan="4" bgcolor="f7f4f4"> <div align="left">Fl&aacute;via Oliveira 
              Ribeiro </div></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td bgcolor="f7f4f4">CPF:</td>
          <td colspan="4" bgcolor="f7f4f4"> <div align="left">803.523.831-00</div></td>
        </tr>
        <tr> 
          <td height="13">&nbsp;</td>
          <td bgcolor="#C0C0C0"><strong><font color="#FFFFFF">N&ordm; Contrato</font></strong></td>
          <td width="98" bgcolor="#CCCCCC"> <div align="center"><strong><font color="#FFFFFF">Valor 
              Contrato</font></strong></div></td>
          <td width="112" bgcolor="#CCCCCC"> <div align="center"><strong><font color="#FFFFFF">Qtde 
              de Parcelas</font></strong></div></td>
          <td width="86" bgcolor="#CCCCCC"> <div align="center"><strong><font color="#FFFFFF">In&iacute;cio 
              </font></strong></div></td>
          <td width="109" bgcolor="#CCCCCC"> <div align="center"><strong><font color="#FFFFFF">Vencimento 
              Final </font></strong></div></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td><strong><a href="emprestimosmodelocontrato.php">42.2792023</a></strong></td>
          <td><div align="center">1.061,00</div></td>
          <td><div align="center">12</div></td>
          <td><div align="center">28/09/2004</div></td>
          <td><div align="center"><font color="#003366">07/10/2005</font></div></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td><strong>43.9808357</strong></td>
          <td><div align="center">1.130,00</div></td>
          <td><div align="center">12</div></td>
          <td><div align="center">13/01/2005</div></td>
          <td><div align="center"><font color="#003366">07/01/2006</font></div></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td><strong>44.8600793</strong></td>
          <td><div align="center">464,00</div></td>
          <td><div align="center">9</div></td>
          <td><div align="center">07/03/2005</div></td>
          <td><div align="center"><font color="#003366">07/12/2005</font></div></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td><strong>43.9808357</strong></td>
          <td><div align="center">251,00</div></td>
          <td><div align="center">5</div></td>
          <td><div align="center">13/01/2005</div></td>
          <td><div align="center"><font color="#003366">07/01/2006</font></div></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td><strong>44.8600793</strong></td>
          <td><div align="center">1650,00</div></td>
          <td><div align="center">12</div></td>
          <td><div align="center">13/01/2005</div></td>
          <td><div align="center"><font color="#003366">07/01/2006</font></div></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td><strong>44.8600793</strong></td>
          <td><div align="center">630,00</div></td>
          <td><div align="center">4</div></td>
          <td><div align="center">07/03/2005</div></td>
          <td><div align="center"><font color="#003366">07/01/2006</font></div></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td><strong>43.9808357</strong></td>
          <td><div align="center">1.525,00</div></td>
          <td><div align="center">9</div></td>
          <td><div align="center">28/09/2004</div></td>
          <td><div align="center"><font color="#003366">07/01/2006</font></div></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td bgcolor="f7f4f4"><strong>43.9808357</strong></td>
          <td bgcolor="f7f4f4"> <div align="center">2500,00</div></td>
          <td bgcolor="f7f4f4"> <div align="center">11</div></td>
          <td bgcolor="f7f4f4"> <div align="center">28/09/2004</div></td>
          <td bgcolor="f7f4f4"> <div align="center"><font color="#003366">07/01/2006</font></div></td>
        </tr>
      </table>
      <table width="100" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td>&nbsp;</td>
        </tr>
      </table>
      <table width="526" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td><div align="right"><img src="img/bt_imprimir.gif" width="67" height="20"></div></td>
        </tr>
      </table> </td>
    <td width="234" valign="top"><img src="img/atencao.gif" width="234" height="324"></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="img/rodape.gif" width="770" height="63"></td>
  </tr>
</table>
</body>
</html>
