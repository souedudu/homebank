<?
session_start();
session_unset();
session_destroy();

//abertura de conex�o com o BD
Conexao($opcao='open',conexao_host,conexao_user,conexao_pass,conexao_db);
?><head>
<title>:. HOMEBANKING .:</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="site.css" rel="stylesheet" type="text/css">
</head>

<form id="formLogin" name="formLogin" method="post" action="index.php" onsubmit="return ValLogin();">
<table align="center" border="0" cellpadding="0" cellspacing="0">
        <tr>
            <td colspan="2" align="center">
                <?
                  if(!empty($ValLoginErro))
                  {
                   echo($ValLoginErro);
                  }
                ?>
            </td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td colspan="2" align="center"><font color="#A2A251">&nbsp;<b></b></font></td>
            <td>&nbsp;</td>
        </tr>
        <tr class="td2">
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr class="td2">
            <td width="90" align="right"><font color="#F2F8E4">Usu�rio&nbsp;</td>
            <td width="200"><input name="txtContaCorrente" type="text"  id="txtContaCorrente" value="" size="20" maxlength="11" /></td>
        </tr>
        <tr class="td2">
            <td align="right"><font color="#F2F8E4">Senha&nbsp;</td>
            <td><input name="txtSenha" type="password" id="txtSenha" value="" size="20" maxlength="15" /></td>
        </tr>
        <tr class="td2">
            <td>&nbsp;</td>
            <td><input name="btLogin" type="submit" id="btLogin" value="Entrar" /></td>
        </tr>
        <tr class="td2">
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
</table>
<BR><BR><BR><BR><BR>
<BR><BR><BR><BR><BR>
<table border="0" cellpadding="0" cellspacing="0">
        <tr bgcolor="dedfd0">
           <td colspan="4"><img src="img/noticias.gif" width="116" height="21" /></td>
        </tr>
        <tr>
            <td width="20"><img src="img/dot_branco.jpg" width="20" height="8" /></td>
            <td width="242">&nbsp;</td>
            <td width="12" rowspan="4" valign="top" background="img/tracado.jpg"><img src="img/tracadoimg.jpg" width="11" height="6" /></td>
            <td width="251">&nbsp;</td>
        </tr>
<?
  $sql = "select * from noticia
          where
               flaativo = 's'
          order by datcadastro desc";
  $rsquery = mysql_query($sql);
  $dados = mysql_fetch_array($rsquery);
  $i = 1;
  while ($i <= 1)
  {
   echo "<tr>
            <td height='41'>&nbsp;</td>
            <td valign='top'><div align='justify'>".$dados['desnoticia']."</div></td>";
   $desurl1 = $dados['desurl'];
   $dados = mysql_fetch_array($rsquery);
   echo "   <td valign='top'><div align='justify'>".$dados['desnoticia']."</div></td>
        </tr>";
   $desurl2 = $dados['desurl'];

   $i++;
   }
?>
        <tr>
            <td>&nbsp;</td>
            <td><div align="right"><a href="http://<? echo $desurl1;?>" target="new"><img src="img/saibamais.jpg" width="67" height="12" border="0"/></a></div></td>
            <td><div align="right"><a href="http://<? echo $desurl2;?>" target="new"><img src="img/saibamais.jpg" width="67" height="12" border="0" /></a></div></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
</table>
</form>
