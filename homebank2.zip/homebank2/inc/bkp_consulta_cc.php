<table width="534" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="534"><img src="img/dot_branco.jpg" width="1" height="10"></td>
        </tr>
      </table>
      <table width="527" border="0" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF">
        <tr> 
          <td width="32" height="16"><img src="img/dot_branco.jpg" width="30" height="1"></td>
          <td colspan="5" valign="top"><strong>Saldo da Conta Corrente</strong></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td width="83" bgcolor="f7f4f4"> <div align="left">Data </div></td>
          <td width="98" bgcolor="f7f4f4"> <div align="center">Ag. de Origem</div></td>
          <td width="91" bgcolor="f7f4f4"> <div align="center">Hist&oacute;rico</div></td>
          <td width="130" bgcolor="f7f4f4"> <div align="center">Documento</div></td>
          <td width="86" bgcolor="f7f4f4"> <div align="center">Valor</div></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td bgcolor="f7f4f4">02/09/2005</td>
          <td bgcolor="f7f4f4"> <div align="center">0000</div></td>
          <td bgcolor="f7f4f4"> <div align="center">saldo anterior</div></td>
          <td bgcolor="f7f4f4"> <div align="center">0000</div></td>
          <td bgcolor="f7f4f4"> <div align="center"><font color="#003366">633,06C</font></div></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>12/09/2005</td>
          <td><div align="center">0000</div></td>
          <td><div align="center">DISPON&Iacute;VEL</div></td>
          <td><div align="center">0000</div></td>
          <td><div align="center"><font color="#003366"><strong>450,23C</strong></font></div></td>
        </tr>
      </table>
      <table width="526" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="150" height="32"><img src="img/dot_branco.jpg" width="150" height="8"></td>
          <td width="84" valign="bottom"><img src="img/bt_imprimir.gif" width="67" height="20"></td>
          <td width="66" valign="bottom"><img src="img/bt_voltar.gif" width="53" height="20"></td>
          <td width="226" valign="bottom"><img src="img/bt_sair.gif" width="52" height="21"></td>
        </tr>
      </table>