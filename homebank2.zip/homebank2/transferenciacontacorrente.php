<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>:. homebanking .:</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilo.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style1 {color: #000000}
-->
</style>
</head>

<body background="img/bg.gif" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="top"> 
    <td width="259"><a href="index.php"><img src="img/logomarca.jpg" width="284" height="61" border="0"></a></td>
    <td width="511" valign="bottom" background="img/bg_topo.jpg">
<table width="475" border="0" cellspacing="0" cellpadding="0">
        <tr valign="top"> 
          <td width="75"><img src="img/contacorrente2.gif" width="75" height="17"></td>
          <td width="48" valign="middle"><font color="#FFFFFF">11604-7</font></td>
          <td width="9" valign="top"><font color="#FFFFFF">_</font></td>
          <td width="125" valign="middle"><font color="#FFFFFF">Fl&aacute;vio 
            Soares Fraz&atilde;o</font></td>
          <td width="80" valign="middle"><img src="img/ultimo_acesso.jpg" width="75" height="17"> 
          </td>
          <td width="138" valign="middle"><font color="#FFFFFF">12/09/2005 - 08:32 
            hs</font></td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="197" valign="top" background="img/bg_caixapostal.jpg"><img src="img/miolo_topo1.jpg" width="203" height="146"></td>
    <td width="573" rowspan="2" valign="top"><img src="img/miolo_topo2.jpg" width="567" height="188"></td>
  </tr>
  <tr> 
    <td height="34" valign="top" background="img/bg_caixapostal.jpg">
<table width="203" height="34" border="0" cellpadding="0" cellspacing="5">
        <tr>
          <td width="193" height="24" valign="top"><font color="#FFFFFF">Voc&ecirc; 
            tem 02 mensagens novas na sua caixa de entrada.</font></td>
        </tr>
      </table></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="5" valign="top" bgcolor="#FFFFFF"><img src="img/dot_branco.jpg" width="1" height="5"></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="top"> 
    <td width="203"><img src="img/contacorrente.gif" width="203" height="21"></td>
    <td width="335" bgcolor="828916">&nbsp;</td>
    <td width="232"><img src="img/importante.gif" width="234" height="21"></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td valign="top"><table width="534" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="534"><img src="img/dot_branco.jpg" width="1" height="10"></td>
        </tr>
      </table>
      <table width="533" border="0" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF">
        <tr> 
          <td width="30" height="16"><img src="img/dot_branco.jpg" width="30" height="8"></td>
          <td colspan="2" valign="top"><strong>Transfer&ecirc;ncia 
            entre conta correntes </strong></td>
        </tr>
        <tr> 
          <td height="139">&nbsp;</td>
          <td colspan="2" valign="top">Seu limite di&aacute;rio de transfer&ecirc;ncia 
            entre contas de titularidades diferentes &eacute; de R$ 600,00.<br> 
            <br>
            Para transfer&ecirc;ncias acima de R$ 600,00 e at&eacute; R$ 30.000,00 
            (inclusive), cadastre as contas que receber&atilde;o os cr&eacute;ditos 
            na ag&ecirc;ncia detentora da sua conta corrente, com dois dias &uacute;teis 
            de anteced&ecirc;ncia. O dia &uacute;til come&ccedil;a a ser contado 
            a partir da zero hora do dia &uacute;til seguinte ao cadastramento.<br> 
            <br>
            O limite para transfer&ecirc;ncias nos finais de semana n&atilde;o 
            &eacute; di&aacute;rio. A soma das transfer&ecirc;ncias de s&aacute;bado, 
            domingo e segunda-feira n&atilde;o poder&aacute; ultrapassar a R$ 
            600,00.</td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td colspan="2"> <div align="left"><span class="style1"><strong>Data de Abertura:</strong> 
              </span>26/09/2005</div></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2">&nbsp;</td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td colspan="2"><span class="style1"><strong>Aberta por: </strong></span><span class="style1">Diego Rodrigo Marra e Silva </span></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2"><strong><font color="#990000">D&eacute;bito:</font></strong></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Ag&ecirc;ncia: </td>
          <td width="452">3596-8</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Conta:</td>
          <td>5236-4</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2"><strong><font color="#003399">Cr&eacute;dito:</font></strong></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Ag&ecirc;ncia:</td>
          <td><input type="text" name="textfield3"></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>Conta:</td>
          <td><input type="text" name="textfield32"></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2"><table width="300" border="0" cellspacing="1" cellpadding="0">
            <tr>
              <td width="136" bgcolor="f7f4f4">Detalhes da Solicita&ccedil;&atilde;o: </td>
              <td width="161"><textarea name="textarea" cols="30"></textarea></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2"><strong>Informa&ccedil;&otilde;es para contato: </strong></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2"><table width="302" border="0" cellspacing="1" cellpadding="0">
            <tr>
              <td width="56" bgcolor="f7f4f4">E-mail:</td>
              <td width="243"><input type="text" name="textfield"></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2"><table width="300" border="0" cellspacing="1" cellpadding="0">
            <tr>
              <td width="57" bgcolor="f7f4f4">Telefone:</td>
              <td width="240"><input type="text" name="textfield2">
            </tr>
          </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="2">&nbsp;</td>
        </tr>
      </table>
      <table width="526" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="150" height="21"><img src="img/dot_branco.jpg" width="150" height="8"></td>
          <td width="98" valign="bottom">&nbsp;</td>
          <td width="33" valign="bottom"><img src="img/BT_OK.gif" width="33" height="21"></td>
          <td width="245" valign="bottom"><img src="img/BT_LIMPAR.gif" width="59" height="21"></td>
        </tr>
    </table> </td>
    <td width="234" valign="top"><img src="img/atencao.gif" width="234" height="324"></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="img/rodape.gif" width="770" height="63"></td>
  </tr>
</table>
</body>
</html>
