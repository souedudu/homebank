<table width="534" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="534"><img src="img/dot_branco.jpg" width="1" height="10"></td>
        </tr>
      </table>
      <table width="527" border="0" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF">
        <tr> 
          <td width="38" height="16"><img src="img/dot_branco.jpg" width="30" height="1"></td>
          <td colspan="4" valign="top"><strong>Saldo do Cart&atilde;o de Cr&eacute;dito</strong></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td width="99" bgcolor="f7f4f4"> <div align="left">Data </div></td>
          <td width="100" bgcolor="f7f4f4"> <div align="center">N&ordm; do Cart&atilde;o</div></td>
          <td width="171" bgcolor="f7f4f4"> <div align="center">Descri&ccedil;&atilde;o 
              Cart&atilde;o </div></td>
          <td width="113" bgcolor="f7f4f4"> <div align="center">Nome do Cliente</div></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>12/09/2005</td>
          <td><div align="center">0000</div></td>
          <td><div align="center">Bancoob Visa Gold</div></td>
          <td><div align="center">Fl&aacute;vio Fraz&atilde;o</div></td>
        </tr>
      </table>
      <table width="526" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="150" height="32"><img src="img/dot_branco.jpg" width="150" height="8"></td>
          <td width="84" valign="bottom"><img src="img/bt_imprimir.gif" width="67" height="20"></td>
          <td width="66" valign="bottom"><img src="img/bt_voltar.gif" width="53" height="20"></td>
          <td width="226" valign="bottom"><img src="img/bt_sair.gif" width="52" height="21"></td>
        </tr>
      </table>