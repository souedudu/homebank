<?
  include "index.php";
?>