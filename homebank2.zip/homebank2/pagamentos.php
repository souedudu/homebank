<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>:. homebanking .:</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilo.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style1 {
	color: #1E5695;
	font-weight: bold;
}
.style2 {
	color: #003366;
	font-weight: bold;
}
.style4 {color: #000000; font-weight: bold; }
.style5 {
	color: #993300;
	font-weight: bold;
}
-->
</style>
</head>

<body background="img/bg.gif" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="top"> 
    <td width="259"><a href="index.php"><img src="img/logomarca.jpg" width="284" height="61" border="0"></a></td>
    <td width="511" valign="bottom" background="img/bg_topo.jpg">
<table width="475" border="0" cellspacing="0" cellpadding="0">
        <tr valign="top"> 
          <td width="75"><img src="img/contacorrente2.gif" width="75" height="17"></td>
          <td width="48" valign="middle"><font color="#FFFFFF">11604-7</font></td>
          <td width="9" valign="top"><font color="#FFFFFF">_</font></td>
          <td width="125" valign="middle"><font color="#FFFFFF">Fl&aacute;vio 
            Soares Fraz&atilde;o</font></td>
          <td width="80" valign="middle"><img src="img/ultimo_acesso.jpg" width="75" height="17"> 
          </td>
          <td width="138" valign="middle"><font color="#FFFFFF">12/09/2005 - 08:32 
            hs</font></td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="197" valign="top" background="img/bg_caixapostal.jpg"><img src="img/miolo_topo1.jpg" width="203" height="146"></td>
    <td width="573" rowspan="2" valign="top"><img src="img/miolo_topo2.jpg" width="567" height="188"></td>
  </tr>
  <tr> 
    <td height="34" valign="top" background="img/bg_caixapostal.jpg">
<table width="203" height="34" border="0" cellpadding="0" cellspacing="5">
        <tr>
          <td width="193" height="24" valign="top"><font color="#FFFFFF">Voc&ecirc; 
            tem 02 mensagens novas na sua caixa de entrada.</font></td>
        </tr>
      </table></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="5" valign="top" bgcolor="#FFFFFF"><img src="img/dot_branco.jpg" width="1" height="5"></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="top"> 
    <td width="203"><img src="img/contacorrente.gif" width="203" height="21"></td>
    <td width="335" bgcolor="828916">&nbsp;</td>
    <td width="232"><img src="img/importante.gif" width="234" height="21"></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td width="536" valign="top"><table width="534" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="534"><img src="img/dot_branco.jpg" width="1" height="10"></td>
        </tr>
      </table>
      <table width="527" border="0" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF">
        <tr>
          <td height="16">&nbsp;</td>
          <td width="488" colspan="6" valign="top"><strong>Pagamentos</strong><br></td>
        </tr>
        <tr> 
          <td width="31" height="100"><img src="img/dot_branco.jpg" width="30" height="1"></td>
          <td colspan="6" valign="top">Seu Limite di&aacute;rio para pagamentos 
            &eacute; de R$ 1.000,00. Para pagamentos acima de R$ 1.000,00 e at&eacute; 
            R$ 2.000,00 fa&ccedil;a o agendamento com 2 dias &uacute;teis de anteced&ecirc;ncia. 
            O dia &uacute;til come&ccedil;a a ser contado a partir da zero hora 
            do dia &uacute;til seguinte ao agendamento do pagamento. <br> <br>
            Hor&aacute;rio limite para pagamentos nesta data: 21 horas (hor&aacute;rio 
            de Bras&iacute;lia). Ap&oacute;s esse hor&aacute;rio, voc&ecirc; poder&aacute; 
            fazer somente agendamentos. <br>
            <br>
            <table width="503" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td colspan="4"><span class="style4">Hor&aacute;rio Limite para pagamento: 21h:00</span></td>
              </tr>
              <tr>
                <td colspan="4">&nbsp;</td>
              </tr>
              <tr>
                <td colspan="4"><table width="499" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="195"><span class="style5">Cr&eacute;dito:</span></td>
                    <td width="304">&nbsp;</td>
                  </tr>
                  <tr>
                    <td colspan="2">&nbsp;</td>
                    </tr>
                </table></td>
              </tr>
              <tr>
                <td colspan="4"><table width="494" border="0" cellspacing="1" cellpadding="0">
                  <tr>
                    <td width="66"><input name="textfield2" type="text" size="11"></td>
                    <td width="66"><input name="textfield3" type="text" size="11"></td>
                    <td width="66"><input name="textfield" type="text" size="11"></td>
                    <td width="66"><input name="textfield4" type="text" size="11"></td>
                    <td width="12">&nbsp;</td>
                    <td width="211">Digite o c&oacute;digo de barras </td>
                  </tr>
                </table>                </td>
              </tr>
              <tr>
                <td><strong>Data de Vencimento:</strong></td>
                <td width="230"><input name="textfield22" type="text" size="4">
                  /
                  <input name="textfield222" type="text" size="4">
                  /
                  <input name="textfield223" type="text" size="8"></td>
                <td width="95">DD/MM/AAAA</td>
                <td width="55">&nbsp;</td>
              </tr>
              <tr>
                <td width="123"><strong>Cedente: </strong></td>
                <td colspan="3"><input name="textfield5" type="text" size="45"></td>
              </tr>
              <tr>
                <td><strong>Sacado: </strong></td>
                <td colspan="3"><input name="textfield52" type="text" size="45"></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td colspan="3">&nbsp;</td>
              </tr>
              <tr>
                <td colspan="4"><strong>Data do Pagamento: </strong></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td colspan="3">&nbsp;</td>
              </tr>
              <tr>
                <td><input name="radiobutton" type="radio" value="radiobutton">
                  Pagar hoje </td>
                <td colspan="3">&nbsp;</td>
              </tr>
              <tr>
                <td><input name="radiobutton" type="radio" value="radiobutton">
                  Agendar para: </td>
                <td colspan="3"><input name="textfield224" type="text" size="4">
                  /
                  <input name="textfield225" type="text" size="4">
                  /
                  <input name="textfield226" type="text" size="8"> </td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td colspan="3">&nbsp;</td>
              </tr>
            </table>
            <table width="489" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="365"><div align="right"><img src="img/BT_OK.gif" width="33" height="21"></div></td>
                <td width="124"><img src="img/BT_LIMPAR.gif" width="59" height="21"></td>
              </tr>
            </table>            <br></td>
        </tr>
      </table>
    </td>
    <td width="234" valign="top"><img src="img/atencao.gif" width="234" height="324"></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="img/rodape.gif" width="770" height="63"></td>
  </tr>
</table>
</body>
</html>
