<a href="javascript:(history.back(-1))">
	<img src="img/bt_voltar.gif" width="53" height="20" border="0" />
</a>&nbsp;&nbsp;&nbsp;<a href="sair.php"><img src="img/bt_sair.gif" width="52" height="21" border="0" /></a>