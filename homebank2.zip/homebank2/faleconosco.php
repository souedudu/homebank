<?
	include "index.php";
?>