<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>:. homebanking .:</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilo.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style1 {
	color: #FFFFFF;
	font-weight: bold;
}
-->
</style>
</head>

<body background="img/bg.gif" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="top"> 
    <td width="259"><a href="index.php"><img src="img/logomarca.jpg" width="284" height="61" border="0"></a></td>
    <td width="511" valign="bottom" background="img/bg_topo.jpg">
<table width="475" border="0" cellspacing="0" cellpadding="0">
        <tr valign="top"> 
          <td width="75"><img src="img/contacorrente2.gif" width="75" height="17"></td>
          <td width="48" valign="middle"><font color="#FFFFFF">11604-7</font></td>
          <td width="9" valign="top"><font color="#FFFFFF">_</font></td>
          <td width="125" valign="middle"><font color="#FFFFFF">Fl&aacute;vio 
            Soares Fraz&atilde;o</font></td>
          <td width="80" valign="middle"><img src="img/ultimo_acesso.jpg" width="75" height="17"> 
          </td>
          <td width="138" valign="middle"><font color="#FFFFFF">12/09/2005 - 08:32 
            hs</font></td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="197" valign="top" background="img/bg_caixapostal.jpg"><img src="img/miolo_topo1.jpg" width="203" height="146"></td>
    <td width="573" rowspan="2" valign="top"><img src="img/miolo_topo2.jpg" width="567" height="188"></td>
  </tr>
  <tr> 
    <td height="34" valign="top" background="img/bg_caixapostal.jpg">
<table width="203" height="34" border="0" cellpadding="0" cellspacing="5">
        <tr>
          <td width="193" height="24" valign="top"><font color="#FFFFFF">Voc&ecirc; 
            tem 02 mensagens novas na sua caixa de entrada.</font></td>
        </tr>
      </table></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="5" valign="top" bgcolor="#FFFFFF"><img src="img/dot_branco.jpg" width="1" height="5"></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="top"> 
    <td width="203"><img src="img/contacorrente.gif" width="203" height="21"></td>
    <td width="335" bgcolor="828916">&nbsp;</td>
    <td width="232"><img src="img/importante.gif" width="234" height="21"></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td width="536" valign="top"><table width="534" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="534"><img src="img/dot_branco.jpg" width="1" height="10"></td>
        </tr>
      </table>
      <table width="527" border="0" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF">
        <tr>
          <td height="16">&nbsp;</td>
          <td width="488" colspan="6" valign="top"><strong>Seguros</strong><br></td>
        </tr>
        <tr> 
          <td width="31" height="100"><img src="img/dot_branco.jpg" width="30" height="1"></td>
          <td colspan="6" valign="top">Seu Limite di&aacute;rio para pagamentos 
            &eacute; de R$ 1.000,00. Para pagamentos acima de R$ 1.000,00 e at&eacute; 
            R$ 2.000,00 fa&ccedil;a o agendamento com 2 dias &uacute;teis de anteced&ecirc;ncia. 
            O dia &uacute;til come&ccedil;a a ser contado a partir da zero hora 
            do dia &uacute;til seguinte ao agendamento do pagamento. <br> <br>
            Hor&aacute;rio limite para pagamentos nesta data: 21 horas (hor&aacute;rio 
            de Bras&iacute;lia). Ap&oacute;s esse hor&aacute;rio, voc&ecirc; poder&aacute; 
            fazer somente agendamentos. <br>            <br>
            <table width="491" border="0" cellspacing="1" cellpadding="0">
              <tr bgcolor="#ADADAD">
                <td colspan="3"><span class="style1">Dados Pessoais</span></td>
              </tr>
              <tr>
                <td colspan="3">&nbsp;</td>
              </tr>
              <tr>
                <td width="138" bgcolor="#F3F3F3">Nome do Segurado: </td>
                <td colspan="2"><input type="text" name="textfield"></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Data de Nascimento do Segurado: </td>
                <td width="212"><input name="textfield2" type="text" size="4">
                  /
                  <input name="textfield22" type="text" size="4">
                  /
                  <input name="textfield23" type="text" size="8"></td>
                <td width="137">DD/MM/AAAA</td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Propriet&aacute;rio do Ve&iacute;culo: </td>
                <td colspan="2"><input type="text" name="textfield3"></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Data de Nascimento do propriet&aacute;rio: </td>
                <td><input name="textfield24" type="text" size="4">
/
  <input name="textfield222" type="text" size="4">
/
<input name="textfield232" type="text" size="8"></td>
                <td>DD/MM/AAAA</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td colspan="2">&nbsp;</td>
              </tr>
            </table>
            <table width="491" border="0" cellspacing="1" cellpadding="0">
              <tr bgcolor="#ADADAD">
                <td colspan="3"><span class="style1">Ve&iacute;culo</span></td>
              </tr>
              <tr>
                <td colspan="3">&nbsp;</td>
              </tr>
              <tr>
                <td width="138" bgcolor="#F3F3F3">Ve&iacute;culo: </td>
                <td colspan="2"><input type="text" name="textfield4"></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Ano de Fabrica&ccedil;&atilde;o/Modelo: </td>
                <td width="172"><input type="text" name="textfield5"></td>
                <td width="177">&nbsp;</td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Possui alarme: </td>
                <td colspan="2"><select name="select">
                  <option>Selecione</option>
                  <option>Sim</option>
                  <option>N&atilde;o</option>
                </select></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Combust&iacute;vel: </td>
                <td><select name="select2">
                  <option>Selecione</option>
                  <option>&Aacute;lcool</option>
                  <option>Gasolina</option>
                  <option>Diesel</option>
                  <option>G&aacute;s</option>
                </select></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td colspan="2">&nbsp;</td>
              </tr>
            </table>            <table width="491" border="0" cellspacing="1" cellpadding="0">
              <tr bgcolor="#ADADAD">
                <td colspan="3"><span class="style1">Principal Condutor </span></td>
              </tr>
              <tr>
                <td colspan="3">&nbsp;</td>
              </tr>
              <tr>
                <td width="138" bgcolor="#F3F3F3">Nome: </td>
                <td colspan="2"><input type="text" name="textfield6"></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Data de Nascimento do Condutor: </td>
                <td width="195"><input name="textfield25" type="text" size="4">
      /
        <input name="textfield223" type="text" size="4">
      /
      <input name="textfield233" type="text" size="8"></td>
                <td width="154">DD/MM/AAAA</td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Sexo: </td>
                <td colspan="2"><table width="327" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="108"><select name="select3">
                      <option>Selecione</option>
                      <option>Masculino</option>
                      <option>Feminino</option>
                    </select></td>
                    <td width="71">Estado Civil: </td>
                    <td width="148"><select name="select4">
                      <option>Selecione</option>
                      <option>Solteiro</option>
                      <option>Casado</option>
                      <option>Vi&uacute;vo</option>
                      <option>Desquitado</option>
                                                                                                    </select></td>
                    </tr>
                </table></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Data de Nascimento do propriet&aacute;rio: </td>
                <td><input name="textfield242" type="text" size="4">
      /
        <input name="textfield2222" type="text" size="4">
      /
      <input name="textfield2322" type="text" size="8"></td>
                <td>DD/MM/AAAA</td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Possui Filhos: </td>
                <td colspan="2"><table width="341" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="114"><select name="select5">
                      <option selected>Selecione</option>
                      <option>Sim</option>
                      <option>N&atilde;o</option>
                                                            </select></td>
                    <td width="114">N&uacute;mero de Filhos: </td>
                    <td width="113"><select name="select6">
                      <option selected>Selecione</option>
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                      <option>6</option>
                      <option>7</option>
                      <option>8</option>
                      <option>9</option>
                      <option>10</option>
                      <option>mais...</option>
                                        </select></td>
                    </tr>
                </table></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Idade de cada filho: </td>
                <td colspan="2"><input type="text" name="textfield7"></td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td colspan="3"><table width="484" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="23"><input type="checkbox" name="checkbox" value="checkbox"></td>
                    <td width="461">Eu n&atilde;o quero que meus filhos sejam considerados como condutores do meu ve&iacute;culo,favor calcular sem filhos. </td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Possui garagem em casa: </td>
                <td colspan="2"><select name="select7">
                  <option selected>Selecione</option>
                  <option>Sim</option>
                  <option>N&atilde;o</option>
                </select></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Possui garagem no trabalho: </td>
                <td colspan="2"><select name="select8">
                  <option selected>Selecione</option>
                  <option>Sim</option>
                  <option>N&atilde;o</option>
                </select></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Usa ve&iacute;culo para ir a Faculdade: </td>
                <td colspan="2"><select name="select9">
                  <option selected>Selecione</option>
                  <option>Sim</option>
                  <option>N&atilde;o</option>
                </select></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Possui estacionamento na faculdade:</td>
                <td colspan="2"><select name="select10">
                  <option selected>Selecione</option>
                  <option>Sim</option>
                  <option>N&atilde;o</option>
                </select></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Anos de CNH do Condutor: </td>
                <td colspan="2"><input name="textfield8" type="text" size="3" maxlength="2"></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">CEP da resid&ecirc;ncia onde pernoita o ve&iacute;culo segurado: </td>
                <td colspan="2"><input type="text" name="textfield9"></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Cidade de maior circula&ccedil;&atilde;o com UF: </td>
                <td colspan="2"><input type="text" name="textfield10">
                  /
                  <input name="textfield82" type="text" size="5" maxlength="2"></td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td colspan="3">&nbsp;</td>
              </tr>
            </table>            
            <table width="491" border="0" cellspacing="1" cellpadding="0">
              <tr bgcolor="#ADADAD">
                <td colspan="3"><span class="style1">Renova&ccedil;&atilde;o</span></td>
              </tr>
              <tr>
                <td colspan="3">&nbsp;</td>
              </tr>
              <tr>
                <td width="138" bgcolor="#F3F3F3">Cia. de Seguros da Ap&oacute;lice atual/vencida: </td>
                <td colspan="2"><input type="text" name="textfield42"></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Vencimento da ap&oacute;lice atual/vencida : </td>
                <td width="172"><input name="textfield83" type="text" size="3" maxlength="2">
                  /
                  <input name="textfield84" type="text" size="3" maxlength="2">
                  /
                  <input name="textfield85" type="text" size="6" maxlength="2"></td>
                <td width="177">&nbsp;</td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">B&ocirc;nus/Classe da ap&oacute;lice atual/vencida : </td>
                <td colspan="2"><input type="text" name="textfield522"></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Houve sinistro / batida /colisao no ve&iacute;culo da ap&oacute;lice atual/vencida : </td>
                <td><select name="select11">
                    <option>Selecione</option>
                    <option>Sim</option>
                    <option>N&atilde;o</option>
                                </select></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td colspan="2">&nbsp;</td>
              </tr>
            </table>            <table width="491" border="0" cellspacing="1" cellpadding="0">
              <tr bgcolor="#ADADAD">
                <td colspan="3"><span class="style1">Coberturas Desejadas </span></td>
              </tr>
              <tr>
                <td colspan="3">&nbsp;</td>
              </tr>
              <tr>
                <td width="138" bgcolor="#F3F3F3">Coberturas Desejadas : </td>
                <td width="349" colspan="2"><select name="select13">
                  <option selected>Selecione</option>
                  <option>Selecione</option>
                  <option>LMI RCF - Danos Materiais</option>
                  <option>LMI APP - Morte</option>
                  <option>LMI APP - Invalidez</option>
                  <option>Assist&ecirc;ncia 24h</option>
                  <option>Garantia aos vidros</option>
                  <option>Franquia</option>
                                                </select></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td colspan="2">&nbsp;</td>
              </tr>
            </table>            
            <table width="491" border="0" cellspacing="1" cellpadding="0">
              <tr bgcolor="#ADADAD">
                <td colspan="3"><span class="style1">Contato</span></td>
              </tr>
              <tr>
                <td colspan="3">&nbsp;</td>
              </tr>
              <tr>
                <td width="138" bgcolor="#F3F3F3">Fone Fixo com DDD : </td>
                <td width="349" colspan="2"><input name="textfield422" type="text" size="4">
                -
                <input type="text" name="textfield4222"></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">Celular com DDD : </td>
                <td colspan="2"><input name="textfield4223" type="text" size="4">
-
  <input type="text" name="textfield42222"></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">E-mail: </td>
                <td colspan="2"><input type="text" name="textfield5222"></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td colspan="2">&nbsp;</td>
              </tr>
            </table>            
            <table width="491" border="0" cellspacing="1" cellpadding="0">
              <tr bgcolor="#ADADAD">
                <td colspan="3"><span class="style1">Indique</span></td>
              </tr>
              <tr>
                <td colspan="3">&nbsp;</td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td colspan="3">Informar 02 emails de amigo com possibilidades de seguro novo, renova&ccedil;&atilde;o ou agendamento. </td>
              </tr>
              <tr>
                <td width="138" bgcolor="#F3F3F3">E-mail 01: </td>
                <td colspan="2"><input type="text" name="textfield422222"></td>
              </tr>
              <tr>
                <td bgcolor="#F3F3F3">E-mail 02: </td>
                <td colspan="2"><input type="text" name="textfield52222"></td>
              </tr>
            </table>            <br>
            <table width="489" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="430"><div align="right"><img src="img/BT_OK.gif" width="33" height="21"></div></td>
                <td width="59"><img src="img/BT_LIMPAR.gif" width="59" height="21"></td>
              </tr>
            </table>            <br></td>
        </tr>
      </table>
    </td>
    <td width="234" valign="top"><img src="img/atencao.gif" width="234" height="324"></td>
  </tr>
</table>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="img/rodape.gif" width="770" height="63"></td>
  </tr>
</table>
</body>
</html>
